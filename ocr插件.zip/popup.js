document.addEventListener('DOMContentLoaded', () => {
    const captureBtn = document.getElementById('captureBtn');
    const uploadBtn = document.getElementById('uploadBtn');
    const translateBtn = document.getElementById('translateBtn');
    const previewImg = document.getElementById('preview');
    const ocrResult = document.getElementById('ocrResult');
    const transResult = document.getElementById('transResult');

    // 截图功能
    captureBtn.addEventListener('click', async () => {
        ocrResult.value = "正在启动截图...";
        previewImg.style.display = "none";
        
        try {
            // 1. 获取屏幕流
            const stream = await navigator.mediaDevices.getDisplayMedia({
                video: {
                    displaySurface: "window",
                    cursor: "always"
                },
                audio: false,
                selfBrowserSurface: "exclude",
                systemAudio: "exclude"
            }).catch(err => {
                throw new Error(`截图权限被拒绝: ${err.name}`);
            });

            // 2. 捕获帧
            const track = stream.getVideoTracks()[0];
            const imageCapture = new ImageCapture(track);
            const bitmap = await imageCapture.grabFrame();
            
            // 3. 转换为可用的Blob
            const canvas = new OffscreenCanvas(bitmap.width, bitmap.height);
            const ctx = canvas.getContext('2d');
            ctx.drawImage(bitmap, 0, 0);
            const blob = await canvas.convertToBlob({ type: 'image/png' });
            
            // 4. 显示预览并处理
            previewImg.style.display = "block";
            previewImg.src = URL.createObjectURL(blob);
            await processImage(blob);
            
            // 5. 关闭流
            track.stop();
        } catch (err) {
            let errorMsg = "截图失败: ";
            if (err.name === "NotAllowedError") {
                errorMsg += "您拒绝了截图权限";
            } else if (err.name === "NotFoundError") {
                errorMsg += "未检测到屏幕内容";
            } else {
                errorMsg += err.message;
            }
            ocrResult.value = errorMsg;
            console.error("截图错误详情:", err);
        }
    });

    // 上传图片
    uploadBtn.addEventListener('change', (e) => {
        if (e.target.files.length > 0) {
            processImage(e.target.files[0]);
        }
    });

    // 翻译功能
    translateBtn.addEventListener('click', async () => {
        const text = ocrResult.value.trim();
        if (!text) {
            alert('请先识别文字再翻译');
            return;
        }
        
        const lang = document.getElementById('transLang').value;
        try {
            const response = await fetch('http://localhost:5000/translate', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ text, target_lang: lang })
            });
            
            const data = await response.json();
            transResult.value = data.translation || `翻译错误: ${data.error}`;
        } catch (err) {
            transResult.value = `API请求失败: ${err.message}`;
        }
    });

    // 优化后的图像处理函数
    async function processImage(blob) {
        ocrResult.value = "识别中...";
        
        try {
            const formData = new FormData();
            formData.append('image', blob);
            formData.append('lang', document.getElementById('ocrLang').value);
            
            const response = await fetch('http://localhost:5000/ocr', {
                method: 'POST',
                body: formData
            });
            
            if (!response.ok) throw new Error(`HTTP错误: ${response.status}`);
            
            const data = await response.json();
            ocrResult.value = data.text || "未识别到文字";
        } catch (err) {
            ocrResult.value = `识别失败: ${err.message}`;
            console.error("OCR处理错误:", err);
        }
    }
});