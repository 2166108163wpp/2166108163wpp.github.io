from flask import Flask, request, jsonify
from flask_cors import CORS  # 新增跨域支持
import pytesseract
from deep_translator import BaiduTranslator
from PIL import Image
import io

app = Flask(__name__)
CORS(app)  # 允许所有跨域请求

BAIDU_APPID = "20250628002392349"  # 请替换为你的真实APPID
BAIDU_SECRET_KEY = "X4MC_59OwTDUMSS9B_Wd"

# 语言配置
ocr_langs = {
    "英文": "eng",
    "简体中文": "chi_sim",
    "繁体中文": "chi_tra",
    "日文": "jpn",
    "韩文": "kor",
    "法文": "fra"
}

trans_langs = {
    "简体中文": "zh",
    "繁体中文": "cht",
    "英文": "en",
    "日文": "jp",
    "韩文": "kor",
    "法文": "fra"
}

@app.route('/ocr', methods=['POST', 'OPTIONS'])  # 添加OPTIONS方法支持
def ocr():
    if request.method == 'OPTIONS':
        return _build_cors_preflight_response()
    
    # 检查是否收到图片
    if 'image' not in request.files:
        return jsonify({"error": "请上传图片文件"}), 400
    
    try:
        image_file = request.files['image']
        if image_file.filename == '':
            return jsonify({"error": "未选择文件"}), 400
            
        # 读取图片
        img = Image.open(image_file.stream)
        
        # 获取语言参数
        lang = request.form.get('lang', 'eng')
        
        # OCR识别
        text = pytesseract.image_to_string(img, lang=lang)
        return jsonify({
            "text": text,
            "lang": lang
        })
    except Exception as e:
        return jsonify({"error": f"识别失败: {str(e)}"}), 500

@app.route('/translate', methods=['POST', 'OPTIONS'])
def translate():
    if request.method == 'OPTIONS':
        return _build_cors_preflight_response()
    
    data = request.get_json()
    if not data:
        return jsonify({"error": "请求数据格式错误"}), 400
    
    text = data.get('text', '')
    target_lang = data.get('target_lang', 'zh')
    
    if not text:
        return jsonify({"error": "未提供待翻译文本"}), 400
    
    try:
        translator = BaiduTranslator(
            appid=BAIDU_APPID,
            appkey=BAIDU_SECRET_KEY,
            source='auto',
            target=target_lang
        )
        translation = translator.translate(text)
        return jsonify({
            "translation": translation,
            "original": text,
            "status": "success"
        })
    except Exception as e:
        return jsonify({"error": f"翻译失败: {str(e)}","status": "failed"}), 500

def _build_cors_preflight_response():
    response = jsonify({"status": "preflight"})
    response.headers.add("Access-Control-Allow-Origin", "*")
    response.headers.add("Access-Control-Allow-Headers", "*")
    response.headers.add("Access-Control-Allow-Methods", "*")
    return response

if __name__ == '__main__':
    app.run(port=5000, debug=True)